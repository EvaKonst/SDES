class InvalidInputExc extends Exception{  
 InvalidInputExc(String s){  
  super(s);  
 }  
}  
