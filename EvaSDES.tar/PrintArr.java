class PrintArr
{
  /** Prints array to console  **/
  static void array(int[] array,int length)
  {
    System.out.print(" - ");
   
    for(int i=0;i<length;i++)
    {
      System.out.print(array[i] + " ");
    }
  }

}
